# Data items of the experiment and data analysis:

  1. `dataItems1.sql` stores IssueID(D1), IssueLabels(D2), IssueCreatedAt(D5), IssueClosedAt(D6), PrID(D7), PrLabels(D8), and Files(D11).
  
  2. `dataItems2.sql` stores IssueTitle(D3), IssueContent(D4), PrTitle(D9), and PrContent(D10).
  
  3. OT, LOCM, NOFM, Entropy, NODP, NOC, and IsMPLF(D12-D18) require the above data for calculation.
